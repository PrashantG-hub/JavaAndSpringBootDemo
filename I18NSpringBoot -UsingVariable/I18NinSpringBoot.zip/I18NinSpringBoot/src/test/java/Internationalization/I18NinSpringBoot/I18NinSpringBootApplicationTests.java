package Internationalization.I18NinSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class I18NinSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
